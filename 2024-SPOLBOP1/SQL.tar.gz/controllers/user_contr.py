from flask import Blueprint
from flask import Flask, jsonify
from DAO.userDao import UserDao
from repository.userRepository import UserRepository
from models.Post import Post

userRepository = UserRepository()

controller = Blueprint("user", __name__)

@controller.route('/')
def index():
    return "Hello Banco de Deus!"

@controller.route('/add')
def add():

    user = Post(titulo = "Postagem", conteudo = "quaq", user_id = 1)



    return userRepository.addUsers("RafaPi", "Bruno@example.com")

@controller.route('/ver')
def ver():
    return jsonify(userRepository.buscar_todos_usuarios_json()) 