from DAO.userDao import UserDao

class UserRepository:
    def __init__(self):
        self.userDao = UserDao()

    def buscar_todos_usuarios_json(self):
        listaJson = []

        users = self.userDao.buscar_todos_usuarios()

        for user in users:
           listaJson.append(user.JSon())

        return listaJson
    
    def addUsers(self, nome, email):
        retorno = self.userDao.add_user(nome, email)
        

        print(retorno)

        if retorno:
            return "Adicionado"
        else:
            return "Deu erro"