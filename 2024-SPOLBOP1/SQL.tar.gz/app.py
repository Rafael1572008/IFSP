from flask import Flask, jsonify
from database import db, initdb
from controllers.user_contr import controller

app = Flask(__name__)
app.register_blueprint(controller)

initdb(app)

if __name__ == "__main__":
    app.run()