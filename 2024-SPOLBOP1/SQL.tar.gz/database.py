from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

def initdb(app):

    # Config
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///exemplo.db"


    with app.app_context():
        db.init_app(app)
        db.create_all()