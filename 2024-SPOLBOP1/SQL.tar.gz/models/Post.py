from database import db

class Post(db.Model):
    id = db.Column(db.Integer, primary_key = True)
    titulo = db.Column(db.String(200))
    conteudo = db.Column(db.Text)
    user_fk = db.Column(db.Integer, db.ForeignKey("user.id"), nullable = False)

    autor = db.relationship("User", back_populates = "posts", lazy=True)

    def JSon(self):
        return {"id" : self.id, "titulo" : self.titulo, "conteudo" : self.conteudo}
    
