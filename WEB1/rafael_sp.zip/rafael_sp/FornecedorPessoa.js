import Fornecedor from "./Fornecedor.js";

class FornecedorPessoa extends Fornecedor{

    constructor(nome="sem nome", fone="(00) 1234-1234", rg = "12.135.743-6", cpf="111222333-96"){
        super(nome, fone);
        this.rg = rg;
        this.cpf = cpf;
    }

    setRg(rg){
        this.rg = rg;
    }

    setCpf(cpf){
        this.cpf = cpf
    }

    getRg(){
        return this.rg
    }

    getCpf(){
        return this.cpf
    }
}
export default FornecedorPessoa;