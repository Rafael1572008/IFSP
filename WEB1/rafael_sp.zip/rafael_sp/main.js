import Fornecedor from "./Fornecedor.js";
import FornecedorPessoa from "./FornecedorPessoa.js";

const forncedor = new Fornecedor("Rafael", "(00) 1234-1234");

console.log("Dados do Fornecedor: ");
console.log(`Nome: ${forncedor.getNome()}`);
console.log(`Nome: ${forncedor.getFone()}`);

const fornecedorPessoa = new FornecedorPessoa(
    "Kaio",
    "(11) 1234-6789",
    "13.134.456-6",
    "123.456.789-10"
);

console.log("Dados do Fornecedor: ");
console.log(`Nome: ${fornecedorPessoa.getNome()}`);
console.log(`Nome: ${fornecedorPessoa.getFone()}`);
console.log(`Nome: ${fornecedorPessoa.getRg()}`);
console.log(`Nome: ${fornecedorPessoa.getCpf()}`);