// Criando a class
class Fornecedor{

    // Criando construtor (metodo)
    constructor(nome = "Seu nome", fone = "(00) 1234-1234"){
        this.nome = nome;
        this.fone = fone;
    }

    // Criando os sets
    setNome(nome){
        this.nome = nome
    }

    setFone(fone){
        this.fone = fone
    }

    //Criando gets
    getNome(){
        return this.nome
    }

    getFone(){
        return this.fone
    }
}
export default Fornecedor;